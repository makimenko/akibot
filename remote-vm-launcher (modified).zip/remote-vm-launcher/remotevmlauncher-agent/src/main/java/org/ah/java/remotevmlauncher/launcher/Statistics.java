package org.ah.java.remotevmlauncher.launcher;

public class Statistics {

    public int deletedFiles = 0;
    public int deletedDirs = 0;
    public int totalResorces = 0;
    public int updatedResources = 0;

}
