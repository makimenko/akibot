
public class TestSomeOutputT {

    public static void main(String[] args) throws Exception {
        System.out.println("Hello - this is first output");
        Thread.sleep(2000);
        System.out.println("Next line");
        Thread.sleep(2000);
        System.out.println("And ending now");
        Thread.sleep(1000);
    }
    
}
