Start MARY as a socket server:

maryserver -Dserver=socket
(or change entry 'server' in conf/marybase.config) 
